const data={
    "first_name": "Евгений",
    "last_name": "Куликов",
    "job_title": "web developer",
    "photo": "./images/1.jpg",
    "phone": "89041234567",
    "email": "evgenii49-9@yandex.ru",
    "link": "мои работы на GIT ",
    "address": "Дзержинск",
    "skills": [
        "Creative Development",
        "Branding & Identity",
        "Project Management",
        "Contact Negotiation",
        "Ad Buying & Planning",
        "Product Positioning",
        "Visual Merchandising",
        "Search Engine Ads",
        "Process Improvement"
        
    ],
    "education":[
        ["2012-2015","Нижегородский государственный педагогический университет  им. Козьмы Минина (Мининский университет), Нижний Новгород"],
    ],
    "achievements":[
        ["нет"],
    ],

    "profile": [
        "Прикладная информатика в менеджменте"
    ],

    
};